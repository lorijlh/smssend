<?php

return [
    'mid' => '1012',
    'token' => '90biqb8l4ky8t130s492g0on4ke5',
    'notifyUrl' => '/admin/pay/pkypay_back',
    'returnUrl' => '/admin/pay/pkypay_return',
];