<?php
/**
 * Created by dh2y.
 * Blog: http://blog.csdn.net/sinat_22878395
 * Date: 2018/4/25 0025 19:17
 * For: 验证码配置
 */

return [
    // 验证码字体大小
    'fontSize' => 17,
    // 验证码位数
    'length' => 4,
    // 关闭验证码杂点
    'useNoise' => true,
];
