<?php	
	
 return [
  'version' => 'v3.0',
  'web_name' => '短信群发',
  'keywords' => '短信群发',
  'description' => '短信群发',
  'copyright' => '©2022 gmail.com',
  'copyright_url' => 'https://gmail.com',
  'icp' => '浙ICP备16023455647号-1',
  'statistical' => '',
];