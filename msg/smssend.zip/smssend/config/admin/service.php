<?php

return [
    'Yuntongxun'=>[
        'type' => 'template',
        'name' => '容联.云通讯'
    ],
    'SsyCloud'=>[
        'type' => 'template',
        'name' => 'SSY云'
    ],
    'Aliyun' =>[
        'type' => 'template',
        'name' =>'阿里大鱼'
    ],
    'Tencent' => [
        'type' =>'template',
        'name' => '腾讯短信'
    ],
    'Ucpaas' => [
        'type' => 'template',
        'name' =>'云之讯'
    ],
    'Smsbao'=>[
	'type'=>'text',
	'name'=>'短信宝'
]
];