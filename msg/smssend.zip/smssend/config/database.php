<?php
return 
[
  'type' => 'mysql',
  'hostname' => 'localhost',
  'database' => 'msgsend_com',
  'username' => 'msgsend_com',
  'password' => 'nJiJGyYFH5t2HePR',
  'hostport' => '3306',
  'dsn' => '',
  'params' => 
  [
  ],
  'charset' => 'utf8',
  'prefix' => 'dkewl_',
  'debug' => true,
  'deploy' => 0,
  'rw_separate' => false,
  'master_num' => 1,
  'slave_no' => '',
  'read_master' => false,
  'fields_strict' => true,
  'resultset_type' => 'array',
  'auto_timestamp' => false,
  'datetime_format' => 'Y-m-d H:i:s',
  'sql_explain' => false,
  'builder' => '',
  'query' => '\\think\\db\\Query',
  'break_reconnect' => false,
  'break_match_str' => 
  [
  ],
]
;