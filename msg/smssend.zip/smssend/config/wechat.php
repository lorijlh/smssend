<?php

return [
    'app_id' => 'wxb3f6xxxxxxxxxx',
    'mch_id' => '1457xxxxx2',
    'notify_url' => '/admin/pay/wechat_back',
    'key' => 'mF2suE9sU6Mk1Cxxxxxxxxxx45',
    'cert_client' => './apiclient_cert.pem',
    'cert_key' => './apiclient_key.pem',
];