<?php
/**
 * Created by dailinlin.
 * Date: 2019/6/22 19:17
 * for:
 */


namespace app\mobile\model;


use think\Db;
use think\Model;

class Member extends Model
{
    protected $autoWriteTimestamp = 'datetime';
    protected $pk = 'id';


}