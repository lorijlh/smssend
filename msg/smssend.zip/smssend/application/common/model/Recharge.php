<?php


namespace app\common\model;


use think\Model;

class Recharge extends Model
{
    protected $pk='id';

    protected $autoWriteTimestamp = true;

}