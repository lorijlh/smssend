<?php


namespace app\common\model;


use think\Model;

class Account extends Model
{
    protected $pk='id';

    protected $autoWriteTimestamp = true;

}