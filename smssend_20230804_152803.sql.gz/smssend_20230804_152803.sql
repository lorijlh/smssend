-- MySQL dump 10.13  Distrib 5.7.40, for Linux (x86_64)
--
-- Host: localhost    Database: smssend
-- ------------------------------------------------------
-- Server version	5.7.40-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dkewl_account`
--

DROP TABLE IF EXISTS `dkewl_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dkewl_account` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `symbol` enum('+','-') NOT NULL DEFAULT '+' COMMENT '资金符号',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '资金',
  `balance` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '余额',
  `remark` varchar(255) NOT NULL DEFAULT '',
  `create_time` int(11) DEFAULT NULL COMMENT '添加时间',
  `update_time` int(11) DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='财务明细记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dkewl_account`
--

LOCK TABLES `dkewl_account` WRITE;
/*!40000 ALTER TABLE `dkewl_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `dkewl_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dkewl_admin`
--

DROP TABLE IF EXISTS `dkewl_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dkewl_admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL,
  `admin_name` varchar(60) DEFAULT NULL COMMENT '管理员姓名',
  `password` varchar(64) NOT NULL,
  `token` varchar(32) NOT NULL,
  `email` varchar(128) DEFAULT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '{1:开启,0:关闭}',
  `last_login` int(11) DEFAULT '0' COMMENT '最后登录时间',
  `balance` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '余额',
  `num` int(11) NOT NULL DEFAULT '0' COMMENT '短信剩余条数',
  `vip` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'vip 0普通用户 1会员用户',
  `vip_time` int(11) DEFAULT '0' COMMENT 'vip到期时间',
  `login_ip` varchar(126) DEFAULT '' COMMENT '登录ip',
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='管理员';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dkewl_admin`
--

LOCK TABLES `dkewl_admin` WRITE;
/*!40000 ALTER TABLE `dkewl_admin` DISABLE KEYS */;
INSERT INTO `dkewl_admin` VALUES (1,'admin','Boss','e2cee5bf898e278f3ffa37ba1a274598','J1cAzg','56admin@qq.com',1,1690448750,1.00,9975,1,1751290164,'210.213.75.138',0,0);
/*!40000 ALTER TABLE `dkewl_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `dkewl_admin_group_view`
--

DROP TABLE IF EXISTS `dkewl_admin_group_view`;
/*!50001 DROP VIEW IF EXISTS `dkewl_admin_group_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `dkewl_admin_group_view` AS SELECT 
 1 AS `username`,
 1 AS `uid`,
 1 AS `group_id`,
 1 AS `admin_name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `dkewl_admin_view`
--

DROP TABLE IF EXISTS `dkewl_admin_view`;
/*!50001 DROP VIEW IF EXISTS `dkewl_admin_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `dkewl_admin_view` AS SELECT 
 1 AS `id`,
 1 AS `username`,
 1 AS `admin_name`,
 1 AS `password`,
 1 AS `token`,
 1 AS `email`,
 1 AS `status`,
 1 AS `last_login`,
 1 AS `balance`,
 1 AS `vip`,
 1 AS `num`,
 1 AS `vip_time`,
 1 AS `login_ip`,
 1 AS `create_time`,
 1 AS `update_time`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `dkewl_auth_group`
--

DROP TABLE IF EXISTS `dkewl_auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dkewl_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(100) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `rules` text NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dkewl_auth_group`
--

LOCK TABLES `dkewl_auth_group` WRITE;
/*!40000 ALTER TABLE `dkewl_auth_group` DISABLE KEYS */;
INSERT INTO `dkewl_auth_group` VALUES (1,'超级管理员',1,'1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,32,31,30,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71'),(2,'平台用户',1,'18,23,24,25,27,28,29,30,31,32,33,35,36,37,38,39,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,on,62');
/*!40000 ALTER TABLE `dkewl_auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dkewl_auth_group_access`
--

DROP TABLE IF EXISTS `dkewl_auth_group_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dkewl_auth_group_access` (
  `uid` mediumint(8) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `group_id` (`group_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dkewl_auth_group_access`
--

LOCK TABLES `dkewl_auth_group_access` WRITE;
/*!40000 ALTER TABLE `dkewl_auth_group_access` DISABLE KEYS */;
INSERT INTO `dkewl_auth_group_access` VALUES (1,1);
/*!40000 ALTER TABLE `dkewl_auth_group_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dkewl_auth_rule`
--

DROP TABLE IF EXISTS `dkewl_auth_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dkewl_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(80) NOT NULL DEFAULT '',
  `title` char(20) NOT NULL DEFAULT '',
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `condition` char(100) NOT NULL DEFAULT '',
  `mid` int(8) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `name` (`name`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=72 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dkewl_auth_rule`
--

LOCK TABLES `dkewl_auth_rule` WRITE;
/*!40000 ALTER TABLE `dkewl_auth_rule` DISABLE KEYS */;
INSERT INTO `dkewl_auth_rule` VALUES (1,'admin/menu/remove','删除',1,1,'',4),(2,'admin/menu/edit','编辑',1,1,'',4),(3,'admin/menu/add','添加',1,1,'',4),(4,'admin/menu/index','菜单列表',1,1,'',4),(5,'admin/auth/remove_group','删除',1,1,'',3),(6,'admin/auth/edit_group','编辑',1,1,'',3),(7,'admin/auth/add_group','添加',1,1,'',3),(8,'admin/admin/index','列表',1,1,'',5),(9,'admin/admin/add','添加',1,1,'',5),(10,'admin/admin/edit','编辑',1,1,'',5),(11,'admin/admin/remove','删除',1,1,'',5),(12,'admin/admin/status','状态更改',1,1,'',5),(13,'admin/auth/edit_access','修改',1,1,'',6),(14,'admin/auth/add_access','添加',1,1,'',6),(15,'admin/auth/remove','删除',1,1,'',6),(16,'admin/auth/index','权限列表',1,1,'',6),(17,'admin/auth/group_list','角色列表',1,1,'',3),(18,'admin/sms/index','群发对象',1,1,'',8),(19,'admin/service/index','服务商',1,1,'',7),(20,'admin/service/add','添加',1,1,'',7),(21,'admin/service/edit','编辑',1,1,'',7),(22,'admin/service/remove','删除',1,1,'',7),(23,'admin/sms/add','添加',1,1,'',8),(24,'admin/sms/send','发送短信',1,1,'',8),(25,'admin/sms/remove','删除',1,1,'',8),(26,'admin/service/send','发送短信',1,1,'',7),(27,'admin/sms/repet','去重',1,1,'',8),(28,'admin/sms/bath_remove','一键删除',1,1,'',8),(29,'admin/template/index','列表',1,1,'',54),(30,'admin/template/remove','删除',1,1,'',54),(31,'admin/template/add','添加',1,1,'',54),(32,'admin/template/edit','编辑',1,1,'',54),(33,'admin/template/params','参数值替换',1,1,'',54),(35,'admin/sms/log','发送记录',1,1,'',55),(36,'admin/member/index','我的账号',1,1,'',57),(37,'admin/member/pay_log','充值记录',1,1,'',58),(38,'admin/sms/del_log','删除记录',1,1,'',55),(39,'admin/member/account','财务明细',1,1,'',59),(40,'admin/setting/index','系统设置',1,1,'',10),(41,'admin/setting/base','基础配置',1,1,'',10),(42,'admin/setting/relation','联系配置',1,1,'',10),(43,'admin/setting/redis','Redis配置',1,1,'',10),(44,'admin/links/index','友情链接',1,1,'',11),(45,'admin/links/add','添加',1,1,'',11),(46,'admin/links/edit','编辑',1,1,'',11),(47,'admin/links/remove','删除',1,1,'',11),(48,'admin/document/index','文章列表',1,1,'',12),(49,'admin/document/add','添加',1,1,'',12),(50,'admin/document/edit','编辑',1,1,'',12),(51,'admin/document/remove','删除',1,1,'',12),(52,'admin/document/status','状态更改',1,1,'',12),(53,'admin/setting/pay','支付设置',1,1,'',13),(54,'admin/setting/alipay','支付宝支付',1,1,'',13),(55,'admin/setting/bank','银行卡支付',1,1,'',13),(56,'admin/setting/usdt','USDT支付',1,1,'',13),(57,'admin/goods/index','套餐列表',1,1,'',14),(58,'admin/goods/add','添加',1,1,'',14),(59,'admin/goods/edit','编辑',1,1,'',14),(60,'admin/goods/remove','删除',1,1,'',14),(61,'admin/goods/status','状态更改',1,1,'',14),(62,'admin/tag/index','群组信息',1,1,'',8),(63,'admin/business/recharge','充值管理',1,1,'',61),(64,'admin/business/account','财务管理',1,1,'',62),(65,'admin/business/member','用户管理',1,1,'',63),(66,'admin/business/audit','充值审核',1,1,'',61),(67,'admin/business/remove','删除充值',1,1,'',61),(68,'admin/business/capital','加减款',1,1,'',63),(69,'admin/business/log','短信记录',1,1,'',64),(70,'admin/business/sms_num','加减短信',1,1,'',63),(71,'admin/template/txl','通讯录',1,1,'',14);
/*!40000 ALTER TABLE `dkewl_auth_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dkewl_document`
--

DROP TABLE IF EXISTS `dkewl_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dkewl_document` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `des` varchar(255) NOT NULL DEFAULT '',
  `thumb_img` varchar(255) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `show` tinyint(4) NOT NULL DEFAULT '1',
  `read` int(255) NOT NULL DEFAULT '0',
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='文档介绍';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dkewl_document`
--

LOCK TABLES `dkewl_document` WRITE;
/*!40000 ALTER TABLE `dkewl_document` DISABLE KEYS */;
INSERT INTO `dkewl_document` VALUES (1,'产品功能','一款辅助的短信，群发工具。可绕过短信服务商的模板审核。发你想发的内容','/static/index/img/Product_img1.jpg','<p>一款辅助的短信，群发工具。可绕过短信服务商的模板审核。发你想发的内容</p>',1,2145,1612000086,1612000086),(2,'短信服务商配置','本系统只是工具，不提供短信包。需要去服务商购买，拿到参数在系统里配置。','/static/index/img/Product_img2.jpg','<p>本系统只是工具，不提供短信包。需要去服务商购买，拿到参数在系统里配置。</p>',1,1582,1612000086,1612000086),(3,'申请模板','如果是模板类的短信服务商，需要申请模板。随便申请一个即可','/static/index/img/Product_img2.jpg','<p>如果是模板类的短信服务商，需要申请模板。随便申请一个即可</p>',1,3531,1612000086,1612000086);
/*!40000 ALTER TABLE `dkewl_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dkewl_goods`
--

DROP TABLE IF EXISTS `dkewl_goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dkewl_goods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `day` int(11) NOT NULL COMMENT '天数',
  `give` int(11) NOT NULL DEFAULT '0' COMMENT '赠送天数',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '价格',
  `usdt` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT 'usdt价格',
  `num` int(11) NOT NULL DEFAULT '0' COMMENT '可发送的短信条数',
  `state` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(11) DEFAULT NULL COMMENT '添加时间',
  `update_time` int(11) DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='充值套餐';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dkewl_goods`
--

LOCK TABLES `dkewl_goods` WRITE;
/*!40000 ALTER TABLE `dkewl_goods` DISABLE KEYS */;
INSERT INTO `dkewl_goods` VALUES (1,'1万条[国内套餐通道]',365,0,2350.00,363.63,10000,1,1612000086,1612000086),(2,'1万条[海外套餐通道]',365,0,2550.00,394.58,10000,1,1612000086,1612000086),(3,'5万条[黑五类国内通道]',365,0,10000.00,1547.37,50000,1,1612000086,1612000086),(4,'5万条[黑五类外海通道]',365,0,11000.00,1702.10,50000,1,1612000086,1612000086),(5,'20万条[无限制通道]',999,0,27000.00,4177.89,200000,1,1625027852,1625027852),(6,'50万条[无限制通道]',999,0,55000.00,8510.51,500000,1,1625027872,1625027872);
/*!40000 ALTER TABLE `dkewl_goods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dkewl_links`
--

DROP TABLE IF EXISTS `dkewl_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dkewl_links` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `links` varchar(255) NOT NULL DEFAULT '',
  `state` tinyint(4) NOT NULL DEFAULT '1' COMMENT '上架',
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='友情链接';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dkewl_links`
--

LOCK TABLES `dkewl_links` WRITE;
/*!40000 ALTER TABLE `dkewl_links` DISABLE KEYS */;
INSERT INTO `dkewl_links` VALUES (1,'一淘模板','https://www.56admin.com/',1,1612008141,1612008141);
/*!40000 ALTER TABLE `dkewl_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dkewl_menu`
--

DROP TABLE IF EXISTS `dkewl_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dkewl_menu` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `pid` smallint(6) NOT NULL DEFAULT '0',
  `title` varchar(20) NOT NULL COMMENT '菜单名称',
  `link` varchar(50) DEFAULT NULL COMMENT '链接',
  `icon` varchar(50) DEFAULT NULL COMMENT '字体图标',
  `sort` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=66 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='菜单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dkewl_menu`
--

LOCK TABLES `dkewl_menu` WRITE;
/*!40000 ALTER TABLE `dkewl_menu` DISABLE KEYS */;
INSERT INTO `dkewl_menu` VALUES (1,0,'权限管理','#','Hui-iconfont-user-group',1),(2,0,'短信管理','#','Hui-iconfont-news',3),(3,1,'角色管理','/admin/auth/group_list','',1),(4,1,'菜单模块','/admin/menu/index','',1),(5,1,'用户列表','/admin/admin/index','',1),(6,1,'权限列表','/admin/auth/index','',1),(7,2,'短信服务商','/admin/service/index','',1),(8,2,'群发对象','/admin/sms/index','',1),(9,0,'系统管理','#','Hui-iconfont-jifen',1),(10,9,'系统设置','/admin/setting/index','',1),(11,9,'友情链接','/admin/links/index','',1),(12,9,'文章管理','/admin/document/index','',1),(13,9,'支付设置','/admin/setting/pay','',1),(14,9,'充值套餐','/admin/goods/index','',1),(54,2,'短信模板','/admin/template/index','',1),(55,56,'发送记录','/admin/sms/log','',3),(56,0,'个人中心','#','Hui-iconfont-user2',1),(57,56,'我的账号','/admin/member/index','',4),(58,56,'充值记录','/admin/member/pay_log','',1),(59,56,'财务明细','/admin/member/account','',1),(60,0,'业务管理','#','Hui-iconfont-vip-card2',1),(61,60,'充值管理','/admin/business/recharge','',1),(62,60,'财务管理','/admin/business/account','',1),(63,60,'用户管理','/admin/business/member','',1),(64,60,'短信记录','/admin/business/log','',1),(65,2,'通讯录','/admin/template/txl','',1);
/*!40000 ALTER TABLE `dkewl_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dkewl_phone`
--

DROP TABLE IF EXISTS `dkewl_phone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dkewl_phone` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '所属用户id',
  `phone` varchar(16) NOT NULL COMMENT '手机号',
  `create_time` int(11) DEFAULT NULL COMMENT '添加时间',
  `tag` varchar(64) NOT NULL DEFAULT '' COMMENT 'tag标签',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='短信发送对象表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dkewl_phone`
--

LOCK TABLES `dkewl_phone` WRITE;
/*!40000 ALTER TABLE `dkewl_phone` DISABLE KEYS */;
/*!40000 ALTER TABLE `dkewl_phone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dkewl_recharge`
--

DROP TABLE IF EXISTS `dkewl_recharge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dkewl_recharge` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `out_trade_no` varchar(32) NOT NULL DEFAULT '',
  `uid` int(11) NOT NULL,
  `amount` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `give_amount` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `type` varchar(255) NOT NULL DEFAULT '',
  `goods` varchar(255) NOT NULL DEFAULT '' COMMENT '充值的套餐信息',
  `state` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0待支付，1支付成功，2支付失败',
  `create_time` int(11) DEFAULT NULL COMMENT '添加时间',
  `update_time` int(11) DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='充值记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dkewl_recharge`
--

LOCK TABLES `dkewl_recharge` WRITE;
/*!40000 ALTER TABLE `dkewl_recharge` DISABLE KEYS */;
/*!40000 ALTER TABLE `dkewl_recharge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `dkewl_recharge_view`
--

DROP TABLE IF EXISTS `dkewl_recharge_view`;
/*!50001 DROP VIEW IF EXISTS `dkewl_recharge_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `dkewl_recharge_view` AS SELECT 
 1 AS `username`,
 1 AS `admin_name`,
 1 AS `email`,
 1 AS `id`,
 1 AS `out_trade_no`,
 1 AS `uid`,
 1 AS `amount`,
 1 AS `give_amount`,
 1 AS `type`,
 1 AS `goods`,
 1 AS `state`,
 1 AS `create_time`,
 1 AS `update_time`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `dkewl_rule_menu_view`
--

DROP TABLE IF EXISTS `dkewl_rule_menu_view`;
/*!50001 DROP VIEW IF EXISTS `dkewl_rule_menu_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `dkewl_rule_menu_view` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `title`,
 1 AS `status`,
 1 AS `condition`,
 1 AS `menu`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `dkewl_send_log`
--

DROP TABLE IF EXISTS `dkewl_send_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dkewl_send_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `phone` char(11) NOT NULL DEFAULT '',
  `content` text,
  `state` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1发送成功，2失败',
  `msg` varchar(255) NOT NULL DEFAULT '' COMMENT '错误信息',
  `is_temp` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否是临时加的手机号',
  `create_time` int(11) DEFAULT NULL COMMENT '添加时间',
  `update_time` int(11) DEFAULT NULL COMMENT '修改时间',
  `zt` varchar(100) NOT NULL DEFAULT '0',
  `sid` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='发送记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dkewl_send_log`
--

LOCK TABLES `dkewl_send_log` WRITE;
/*!40000 ALTER TABLE `dkewl_send_log` DISABLE KEYS */;
INSERT INTO `dkewl_send_log` VALUES (1,1,'13666666666','【抖友钱包】您的账户，因为公司发福利了，你原本的5000，金额变化，账户余额20000，进去查询一下吧http://suo.im/4Ddkin',2,'短信模板无效',1,1683949142,1683949142,'0',''),(2,1,'13666666666','你好，收到请回复',0,'',0,1683951879,1683951879,'0',''),(3,1,'13666666666','你好，收到请回复',0,'',0,1683951918,1683951918,'0',''),(4,1,'13666666666','你好，收到请回复',0,'',0,1683952011,1683952011,'0',''),(5,1,'13666666666','你好，收到请回复',0,'',0,1683952027,1683952027,'0',''),(6,1,'13666666666','你好，收到请回复',0,'',0,1683952102,1683952102,'0',''),(7,1,'13666666666','你好，收到请回复',0,'',0,1683952572,1683952572,'0',''),(8,1,'13666666666','你好，收到请回复',0,'',0,1683952628,1683952628,'0',''),(9,1,'13666666666','你好，收到请回复',0,'',0,1683957385,1683957385,'0',''),(10,1,'13666666666','你好，收到请回复',0,'',0,1683957415,1683957415,'0',''),(11,1,'13666666666','你好，收到请回复',0,'',0,1683959960,1683959960,'0',''),(12,1,'13666666666','你好，收到请回复',0,'',0,1683959975,1683959975,'0',''),(13,1,'13666666666','你好，收到请回复',0,'',0,1683960109,1683960109,'0',''),(14,1,'13666666666','你好，收到请回复',0,'',0,1683960212,1683960212,'0',''),(15,1,'13666666666','你好，收到请回复',0,'',0,1683960256,1683960256,'0',''),(16,1,'13666666666','你好，收到请回复',0,'',0,1683960479,1683960479,'0',''),(17,1,'13666666666','你好，收到请回复',0,'',0,1683960777,1683960777,'0',''),(18,1,'13666666666','你好，收到请回复',0,'',0,1683961128,1683961128,'0',''),(19,1,'13666666666','你好，收到请回复',0,'',0,1683961179,1683961179,'0',''),(20,1,'13666666666','你好，收到请回复',0,'',0,1683961448,1683961448,'0',''),(21,1,'13666666666','你好，收到请回复',0,'',0,1683961468,1683961468,'0',''),(22,1,'13666666666','你好，收到请回复',0,'',0,1683961597,1683961597,'0',''),(23,1,'13666666666','不需要',0,'',1,1683949142,1683949142,'1','1');
/*!40000 ALTER TABLE `dkewl_send_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `dkewl_send_log_view`
--

DROP TABLE IF EXISTS `dkewl_send_log_view`;
/*!50001 DROP VIEW IF EXISTS `dkewl_send_log_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `dkewl_send_log_view` AS SELECT 
 1 AS `id`,
 1 AS `uid`,
 1 AS `phone`,
 1 AS `content`,
 1 AS `state`,
 1 AS `msg`,
 1 AS `is_temp`,
 1 AS `create_time`,
 1 AS `update_time`,
 1 AS `username`,
 1 AS `admin_name`,
 1 AS `email`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `dkewl_service`
--

DROP TABLE IF EXISTS `dkewl_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dkewl_service` (
  `id` smallint(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '所属用户id',
  `name` varchar(20) NOT NULL,
  `class_name` varchar(64) NOT NULL DEFAULT '' COMMENT '类名',
  `account` varchar(128) NOT NULL COMMENT '短信账户',
  `password` varchar(64) NOT NULL COMMENT '短信秘钥',
  `signature` varchar(64) NOT NULL COMMENT '短信签名',
  `app_id` varchar(64) NOT NULL DEFAULT '' COMMENT 'app_id',
  `type` varchar(16) NOT NULL DEFAULT '' COMMENT '模板类型',
  `is_use` tinyint(4) NOT NULL DEFAULT '0' COMMENT '选中正在使用',
  `is_test` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否是测试',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='短信服务商表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dkewl_service`
--

LOCK TABLES `dkewl_service` WRITE;
/*!40000 ALTER TABLE `dkewl_service` DISABLE KEYS */;
INSERT INTO `dkewl_service` VALUES (2,1,'云通讯','Yuntongxun','8a216da86b652116016b78c233941083','f7729bdc7f24403c926ce7d2ea81026e','抖友钱包','8a216da86b652116016b78c234041089','template',0,0),(3,0,'黑五类通道[+86]','Yuntongxun','asdasdasd','asdadadqasd','','','template',0,1),(4,0,'大陆通道[0086]','Yuntongxun','111111qq','111111qq','','','template',0,1),(5,0,'国际通道[00855]','Aliyun','111111qq','111111qq','','','template',0,1),(6,0,'一淘模板源码','Smsbao','11111111','1111111111','','','text',0,1),(7,1,'SSY','SsyCloud','FRS-059J-1','IP5sF21n','','','template',1,0);
/*!40000 ALTER TABLE `dkewl_service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dkewl_template`
--

DROP TABLE IF EXISTS `dkewl_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dkewl_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '所属用户id',
  `template_name` varchar(255) NOT NULL DEFAULT '' COMMENT '模板名称',
  `code` varchar(64) NOT NULL COMMENT '模板id',
  `message` text NOT NULL COMMENT '模板内容',
  `sid` int(11) NOT NULL COMMENT '所属服务商',
  `params` text COMMENT '参数内容',
  `signature` varchar(255) NOT NULL DEFAULT '' COMMENT '短信签名',
  `is_use` tinyint(4) NOT NULL DEFAULT '0' COMMENT '选中正在使用',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='短信模板';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dkewl_template`
--

LOCK TABLES `dkewl_template` WRITE;
/*!40000 ALTER TABLE `dkewl_template` DISABLE KEYS */;
INSERT INTO `dkewl_template` VALUES (1,1,'融云模板1','442268','您的账户%name%，因为%reason%，金额变化%money%，账户余额%balance%',2,'{\"name\":\"\",\"reason\":\"\\u516c\\u53f8\\u53d1\\u798f\\u5229\\u4e86\\uff0c\\u4f60\\u539f\\u672c\\u76845000\",\"money\":\"\",\"balance\":\"20000\\uff0c\\u8fdb\\u53bb\\u67e5\\u8be2\\u4e00\\u4e0b\\u5427http:\\/\\/suo.im\\/4Ddkin\"}','抖友钱包',0),(5,0,'一元购','23442','您好，平台限时推出一元购物体检。快来参加体验吧%url%',3,'{\"url\":\"\"}','',0),(6,10,'测试','234234','0元购活动正式开始了，大家赶紧来撸羊毛吧。%url%',3,'{\"url\":\"http:\\/\\/url.cn\\/dddasd\"}','',0),(7,11,'模板1','442269','EGB99 →  %url%',3,'{\"url\":\"www.egb99.com\"}','',0),(8,1,'测试','34453','告诉对方答复不分高低',3,'[]','',0),(9,1,'测试短信','123321','你好，收到请回复',7,'[]','',1);
/*!40000 ALTER TABLE `dkewl_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'smssend'
--

--
-- Dumping routines for database 'smssend'
--

--
-- Final view structure for view `dkewl_admin_group_view`
--

/*!50001 DROP VIEW IF EXISTS `dkewl_admin_group_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`smssend`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `dkewl_admin_group_view` AS select 1 AS `username`,1 AS `uid`,1 AS `group_id`,1 AS `admin_name` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `dkewl_admin_view`
--

/*!50001 DROP VIEW IF EXISTS `dkewl_admin_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`smssend`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `dkewl_admin_view` AS select 1 AS `id`,1 AS `username`,1 AS `admin_name`,1 AS `password`,1 AS `token`,1 AS `email`,1 AS `status`,1 AS `last_login`,1 AS `balance`,1 AS `vip`,1 AS `num`,1 AS `vip_time`,1 AS `login_ip`,1 AS `create_time`,1 AS `update_time` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `dkewl_recharge_view`
--

/*!50001 DROP VIEW IF EXISTS `dkewl_recharge_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`smssend`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `dkewl_recharge_view` AS select 1 AS `username`,1 AS `admin_name`,1 AS `email`,1 AS `id`,1 AS `out_trade_no`,1 AS `uid`,1 AS `amount`,1 AS `give_amount`,1 AS `type`,1 AS `goods`,1 AS `state`,1 AS `create_time`,1 AS `update_time` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `dkewl_rule_menu_view`
--

/*!50001 DROP VIEW IF EXISTS `dkewl_rule_menu_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`smssend`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `dkewl_rule_menu_view` AS select 1 AS `id`,1 AS `name`,1 AS `title`,1 AS `status`,1 AS `condition`,1 AS `menu` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `dkewl_send_log_view`
--

/*!50001 DROP VIEW IF EXISTS `dkewl_send_log_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`smssend`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `dkewl_send_log_view` AS select 1 AS `id`,1 AS `uid`,1 AS `phone`,1 AS `content`,1 AS `state`,1 AS `msg`,1 AS `is_temp`,1 AS `create_time`,1 AS `update_time`,1 AS `username`,1 AS `admin_name`,1 AS `email` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-04 15:28:03
